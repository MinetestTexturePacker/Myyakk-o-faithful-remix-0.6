# Myyakk-o-faithful-remix-0.6
A MC-Like faithful texture for MT
